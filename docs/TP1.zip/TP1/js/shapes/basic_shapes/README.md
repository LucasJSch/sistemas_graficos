This folder contains basic shapes that serve as an interface to WebGL's API to th little bit more high level shapes.

These classes (ideally) should be the only ones that setup buffers in WebGL's pipeline.
