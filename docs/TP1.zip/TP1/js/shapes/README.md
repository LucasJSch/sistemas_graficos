These classes represent basic shapes which serve as the foundations to define real-world shapes.

I.e., in real life we don't have cylinder or cubes. We have tubes or cars, which can be defined in terms of cylinders and cubes.