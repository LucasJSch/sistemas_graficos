class BuildingListener {
    constructor() {
        
    }
}