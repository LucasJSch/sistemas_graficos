class CraneController {
    constructor(craneInstance) {
        this.craneInstance = craneInstance;
    }
}